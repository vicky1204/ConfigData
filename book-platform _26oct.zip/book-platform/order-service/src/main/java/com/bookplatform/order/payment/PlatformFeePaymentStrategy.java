package com.bookplatform.order.payment;

import com.bookplatform.common.TermsAndConditions;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class PlatformFeePaymentStrategy implements PaymentSplitStrategy {

    @Override
    public PaymentBreakdown calculate(BigDecimal unitPrice, int quantity, boolean skipPayment) {
        if (skipPayment) {
            return new PaymentBreakdown(
                    BigDecimal.ZERO.setScale(2),
                    BigDecimal.ZERO.setScale(2),
                    BigDecimal.ZERO.setScale(2),
                    BigDecimal.ZERO.setScale(2)
            );
        }

        BigDecimal checkoutPerBook = TermsAndConditions.checkoutAmountForUnitPrice(unitPrice);
        BigDecimal amountPaid = checkoutPerBook.multiply(BigDecimal.valueOf(quantity));
        BigDecimal feePerBook = TermsAndConditions.platformFeeForUnitPrice(unitPrice);
        BigDecimal totalFee = feePerBook.multiply(BigDecimal.valueOf(quantity));
        BigDecimal refund = amountPaid.subtract(totalFee);
        if (refund.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException(
                    "Checkout amount must be greater than the platform fee (" + TermsAndConditions.PLATFORM_FEE_PERCENT + "%)");
        }
        return new PaymentBreakdown(amountPaid, feePerBook, totalFee, refund);
    }
}
