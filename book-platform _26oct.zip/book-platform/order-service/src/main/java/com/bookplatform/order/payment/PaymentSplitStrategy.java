package com.bookplatform.order.payment;

import java.math.BigDecimal;

/**
 * Strategy pattern: customer pays 90% at checkout; platform keeps 5% of list price, rest is refundable.
 */
public interface PaymentSplitStrategy {
    PaymentBreakdown calculate(BigDecimal unitPrice, int quantity, boolean skipPayment);
}
