# Book Platform — Microservices (Spring Boot)

A demo **book buying platform** with:
- **Microservices** architecture
- **H2 in-memory** databases (Phase 1 — swap to PostgreSQL later)
- **Kafka** optional (works without Kafka install via HTTP fallback)
- **WhatsApp** notifications (mock locally; Twilio-ready interface)
- **Thymeleaf** web UI
- **Two self-serve registration types**: buyer (user) and store owner (classroom-friendly)

## Account types (important for classroom demos)

There is **one login page** (`/login`). What you can do depends on the role created at registration.

| Role | How you get it | What you can do |
|------|----------------|-----------------|
| **USER (Buyer)** | Register → choose **Buyer** | Browse (also works without login), **checkout**, orders, reviews |
| **STORE_ADMIN (Store)** | Register → choose **Store owner** | Own offline store; **add / edit / delete** books; CSV upload |
| **ADMIN (Platform)** | Seeded only (not self-register) | Dashboard, all stores, all books |

### Classroom pattern (~40 students)

1. Each student registers as **Store owner** with a unique email + store name → gets their own store.
2. After login they land on **My Store** (`/store/books`) and manage only their catalog.
3. Anyone (or a separate buyer account) can browse without login and **checkout** as a **Buyer**.
4. Platform admin remains separate for overall monitoring.

### Seeded demo logins (after services start)

| Email | Password | Role |
|-------|----------|------|
| `admin@bookplatform.local` | `admin123` | Platform ADMIN |
| `owner.chapterandchai@bookplatform.local` (and other seeded owners) | `store123` | STORE_ADMIN (demo stores) |

> Start **catalog-service before user-service** so demo store-owner accounts can be linked to seeded stores.

## Business model

1. Anyone can **browse / search** books without login
2. Buyer **registers** (or logs in) to **checkout**
3. Checkout pays listed price; platform keeps **INR 5%** service fee
4. Remaining amount is refundable after return in good condition
5. **Terms & Conditions** must be accepted
6. On **delivery**, WhatsApp notification is sent (mock locally)

## Architecture (local ports)

| Service | Port | Responsibility |
|---------|------|----------------|
| **web-ui** | **8090** | Thymeleaf frontend |
| **api-gateway** | **8080** | Spring Cloud Gateway routes (optional for local UI) |
| **user-service** | **8085** | Registration, login, JWT, community |
| **catalog-service** | **8086** | Books, stores, reviews, inventory |
| **order-service** | **8083** | Checkout, payment split, orders |
| **notification-service** | **8084** | WhatsApp (mock/Kafka consumer) |

Local **web-ui** calls services **directly** (not via gateway):
- `user-url` → `http://localhost:8085`
- `catalog-url` → `http://localhost:8086`
- `order-url` → `http://localhost:8083`

## Design patterns used

- **Repository** — JPA data access
- **Service layer** — business logic
- **DTO** — API contracts in `common` module
- **Strategy** — `PaymentSplitStrategy` (5% fee logic)
- **Factory / Strategy** — `WhatsAppNotifier` (mock vs real provider)
- **Event-driven** — Kafka `order-events` topic (optional)
- **API Gateway** — single entry for REST APIs

## Prerequisites

- **Java 17+**
- **Maven 3.9+**
- **Kafka** — optional (see below)

## Quick start (NO Kafka required)

```bash
cd book-platform
mvn clean package -DskipTests
```

Start services (recommended order):

```bash
# Terminal 1 — catalog first (stores + sample books seed into H2)
mvn -pl catalog-service spring-boot:run

# Terminal 2 — users / JWT (links seeded store owners when catalog is up)
mvn -pl user-service spring-boot:run

# Terminal 3
mvn -pl notification-service spring-boot:run

# Terminal 4
mvn -pl order-service spring-boot:run

# Terminal 5 (optional gateway)
mvn -pl api-gateway spring-boot:run

# Terminal 6 — Web UI
mvn -pl web-ui spring-boot:run
```

**Open:** http://localhost:8090

### Windows script

```powershell
.\scripts\start-all.ps1
```

## Test flows

### A) Buyer checkout

1. Open http://localhost:8090/ — browse books **without** login
2. Register as **Buyer** at http://localhost:8090/register (phone like `919876543210`)
3. Checkout a book → accept Terms → place order
4. **My Orders** → **Simulate Deliver**
5. Check **notification-service** console for WhatsApp mock message

### B) Store owner (student) catalog

1. Register as **Store owner** at http://localhost:8090/register  
   Fill store name, address, city, state, pincode
2. You are redirected to **My Store** (`/store/books`)
3. Add / edit / delete books (or CSV upload)
4. Log out and browse as guest — your books appear in the public catalog
5. Login again with the **same email/password** (store login uses the shared login page)

### Sample books in H2

`catalog-service` seeds stores + sample books on startup via `DataInitializer` (in-memory H2 resets on restart).

- API: http://localhost:8086/api/books  
- H2 console: http://localhost:8086/h2-console — JDBC URL `jdbc:h2:mem:catalogdb`, user `sa`, empty password

## Kafka (Phase 2 — optional)

### Option A: Docker

```bash
docker compose up -d
```

```bash
mvn -pl order-service spring-boot:run -Dspring-boot.run.profiles=kafka
mvn -pl notification-service spring-boot:run -Dspring-boot.run.profiles=kafka
```

### Without Kafka (default)

Order events are sent via **HTTP** directly to notification-service.

## WhatsApp (real integration — Phase 2)

Replace `MockWhatsAppNotifier` with Twilio WhatsApp API:

1. Create Twilio account + WhatsApp sandbox
2. Implement `TwilioWhatsAppNotifier implements WhatsAppNotifier`
3. Set `whatsapp.provider=twilio` in `notification-service`

## Phase 2 enhancements (your plan)

- [ ] PostgreSQL per service
- [ ] Kafka always on (remove HTTP fallback)
- [ ] Real payment gateway (Razorpay/Stripe)
- [ ] Real WhatsApp via Twilio
- [ ] Service discovery (Eureka)
- [ ] Docker/Kubernetes deployment

## API examples

```bash
# Register as buyer (USER)
curl -X POST http://localhost:8085/api/users/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Test Buyer","email":"buyer@example.com","password":"secret1","phone":"919876543210","accountType":"USER"}'

# Register as store owner (creates store in catalog-service, role STORE_ADMIN)
curl -X POST http://localhost:8085/api/users/register \
  -H "Content-Type: application/json" \
  -d "{\"fullName\":\"Student One\",\"email\":\"student1@example.com\",\"password\":\"secret1\",\"phone\":\"919876543211\",\"accountType\":\"STORE\",\"storeName\":\"Student One Books\",\"storeAddressLine\":\"12 College Road\",\"storeCity\":\"Pune\",\"storeState\":\"Maharashtra\",\"storePincode\":\"411001\"}"

# Search books (public)
curl "http://localhost:8086/api/books?q=java"

# Checkout (needs JWT from login — use web-ui for the full flow)
```

## Project structure

```
book-platform/
├── common/                 # Shared DTOs, Feign clients, JWT, T&C
├── user-service/           # Auth + community (port 8085)
├── catalog-service/        # Books + stores (port 8086)
├── order-service/
├── notification-service/
├── api-gateway/
├── web-ui/
├── docker-compose.yml
└── scripts/
```

## License

Demo project for learning — customize as needed.
