#!/usr/bin/env bash
# Run on Oracle Cloud Ubuntu VM after SSH login.
# Usage: bash setup-oracle-vm.sh

set -euo pipefail

echo "Installing k3s..."
curl -sfL https://get.k3s.io | sh -
sudo chmod 644 /etc/rancher/k3s/k3s.yaml
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
grep -q 'KUBECONFIG=/etc/rancher/k3s/k3s.yaml' ~/.bashrc || \
  echo 'export KUBECONFIG=/etc/rancher/k3s/k3s.yaml' >> ~/.bashrc

echo "Installing NGINX Ingress..."
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.11.1/deploy/static/provider/cloud/deploy.yaml
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=180s

echo ""
echo "k3s ready. Clone your repo and deploy:"
echo "  git clone https://github.com/YOUR_GITHUB_USER/book-platform.git"
echo "  cd book-platform"
echo "  kubectl apply -f k8s/"
echo ""
echo "Then open: http://$(curl -s ifconfig.me)"
