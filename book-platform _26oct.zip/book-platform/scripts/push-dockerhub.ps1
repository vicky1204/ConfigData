# Build local images, tag for Docker Hub, and push.
# 1. Set YOUR_DOCKERHUB_USER below
# 2. Run: docker login
# 3. Run: .\scripts\push-dockerhub.ps1

$ErrorActionPreference = "Stop"

# ========== EDIT THIS ==========
$DockerHubUser = "YOUR_DOCKERHUB_USER"
# ===============================

$Version = "1.0.0"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if ($DockerHubUser -eq "YOUR_DOCKERHUB_USER") {
    Write-Error "Set `$DockerHubUser at the top of this script to your Docker Hub username."
}

$services = @(
    "user-service",
    "catalog-service",
    "notification-service",
    "order-service",
    "api-gateway",
    "web-ui"
)

Write-Host "Building images..."
& "$PSScriptRoot\build-docker-images.ps1" -Version $Version

Write-Host "`nTagging and pushing to Docker Hub ($DockerHubUser)..."
foreach ($service in $services) {
    $local = "book-platform/${service}:$Version"
    $remote = "${DockerHubUser}/book-platform-${service}:$Version"
    Write-Host "  $local -> $remote"
    docker tag $local $remote
    docker push $remote
}

Write-Host "`nDone. Images pushed:"
foreach ($service in $services) {
    Write-Host "  https://hub.docker.com/r/${DockerHubUser}/book-platform-${service}"
}

Write-Host "`nNext: replace YOUR_DOCKERHUB_USER in k8s/*.yaml with '$DockerHubUser', then push to GitHub."
