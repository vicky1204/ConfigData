package com.bookplatform.user.community.config;

import com.bookplatform.user.community.entity.CommunityPost;
import com.bookplatform.user.community.entity.CommunityReply;
import com.bookplatform.user.community.repository.CommunityPostRepository;
import com.bookplatform.user.community.repository.CommunityReplyRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CommunityDataInitializer {

    @Bean
    CommandLineRunner seedCommunityPosts(CommunityPostRepository postRepository,
                                         CommunityReplyRepository replyRepository) {
        return args -> {
            if (postRepository.count() > 0) {
                return;
            }

            CommunityPost post1 = savePost(postRepository, 2L, "Priya Sharma",
                    "Best book clubs in Bengaluru?",
                    "Looking for offline book clubs that meet monthly. Any recommendations near Koramangala or Indiranagar?");
            saveReply(replyRepository, post1.getId(), 3L, "Rahul Mehta",
                    "Chapter & Chai Books hosts a Sunday readers circle — worth checking out!");
            saveReply(replyRepository, post1.getId(), 4L, "Ananya Iyer",
                    "I joined one at Lakeview Pages in Pune too. Great community vibe.");

            CommunityPost post2 = savePost(postRepository, 5L, "Vikram Singh",
                    "Tips for returning books in good condition",
                    "What do you all do to keep paperbacks from bending when you carry them daily?");
            saveReply(replyRepository, post2.getId(), 6L, "Meera Nair",
                    "I use a simple cloth cover and avoid keeping them at the bottom of my bag.");

            savePost(postRepository, 7L, "Arjun Patel",
                    "Share your favourite Hindi literature picks",
                    "Just finished Godan and loved it. What should I read next from Premchand or similar authors?");
        };
    }

    private CommunityPost savePost(CommunityPostRepository repository, Long userId, String name,
                                   String title, String body) {
        CommunityPost post = new CommunityPost();
        post.setUserId(userId);
        post.setUserFullName(name);
        post.setTitle(title);
        post.setBody(body);
        return repository.save(post);
    }

    private void saveReply(CommunityReplyRepository repository, Long postId, Long userId,
                           String name, String body) {
        CommunityReply reply = new CommunityReply();
        reply.setPostId(postId);
        reply.setUserId(userId);
        reply.setUserFullName(name);
        reply.setBody(body);
        repository.save(reply);
    }
}
