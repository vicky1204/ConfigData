package com.bookplatform.user.community.controller;

import com.bookplatform.common.dto.CommunityPostDetailDto;
import com.bookplatform.common.dto.CommunityPostDto;
import com.bookplatform.common.dto.CommunityReplyDto;
import com.bookplatform.common.dto.CreateCommunityPostRequest;
import com.bookplatform.common.dto.CreateCommunityReplyRequest;
import com.bookplatform.common.openapi.OpenApiConstants;
import com.bookplatform.user.community.service.CommunityService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/community")
@Tag(name = "Community", description = "Reader community discussions")
public class CommunityController {

    private final CommunityService communityService;

    public CommunityController(CommunityService communityService) {
        this.communityService = communityService;
    }

    @GetMapping("/posts")
    public List<CommunityPostDto> listPosts() {
        return communityService.listPosts();
    }

    @GetMapping("/posts/{id}")
    public CommunityPostDetailDto getPost(@PathVariable("id") Long id) {
        return communityService.getPost(id);
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PostMapping("/posts")
    public ResponseEntity<CommunityPostDto> createPost(@Valid @RequestBody CreateCommunityPostRequest request,
                                                       Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(communityService.createPost(userId, request));
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PostMapping("/posts/{id}/replies")
    public ResponseEntity<CommunityReplyDto> createReply(@PathVariable("id") Long id,
                                                         @Valid @RequestBody CreateCommunityReplyRequest request,
                                                         Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(communityService.createReply(id, userId, request));
    }
}
