package com.bookplatform.user.community.service;

import com.bookplatform.common.dto.CommunityPostDetailDto;
import com.bookplatform.common.dto.CommunityPostDto;
import com.bookplatform.common.dto.CommunityReplyDto;
import com.bookplatform.common.dto.CreateCommunityPostRequest;
import com.bookplatform.common.dto.CreateCommunityReplyRequest;
import com.bookplatform.user.community.entity.CommunityPost;
import com.bookplatform.user.community.entity.CommunityReply;
import com.bookplatform.user.community.mapper.CommunityMapper;
import com.bookplatform.user.community.repository.CommunityPostRepository;
import com.bookplatform.user.community.repository.CommunityReplyRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommunityService {

    private final CommunityPostRepository postRepository;
    private final CommunityReplyRepository replyRepository;

    public CommunityService(CommunityPostRepository postRepository,
                            CommunityReplyRepository replyRepository) {
        this.postRepository = postRepository;
        this.replyRepository = replyRepository;
    }

    public List<CommunityPostDto> listPosts() {
        Map<Long, Integer> replyCounts = replyCounts();
        return postRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(post -> CommunityMapper.toPostDto(post, replyCounts.getOrDefault(post.getId(), 0)))
                .toList();
    }

    public CommunityPostDetailDto getPost(Long postId) {
        CommunityPost post = requirePost(postId);
        int replyCount = (int) replyRepository.countByPostId(postId);
        List<CommunityReplyDto> replies = replyRepository.findByPostIdOrderByCreatedAtAsc(postId).stream()
                .map(CommunityMapper::toReplyDto)
                .toList();
        return new CommunityPostDetailDto(CommunityMapper.toPostDto(post, replyCount), replies);
    }

    @Transactional
    public CommunityPostDto createPost(Long userId, CreateCommunityPostRequest request) {
        CommunityPost post = new CommunityPost();
        post.setUserId(userId);
        post.setUserFullName(request.userFullName().trim());
        post.setTitle(request.title().trim());
        post.setBody(request.body().trim());
        CommunityPost saved = postRepository.save(post);
        return CommunityMapper.toPostDto(saved, 0);
    }

    @Transactional
    public CommunityReplyDto createReply(Long postId, Long userId, CreateCommunityReplyRequest request) {
        requirePost(postId);
        CommunityReply reply = new CommunityReply();
        reply.setPostId(postId);
        reply.setUserId(userId);
        reply.setUserFullName(request.userFullName().trim());
        reply.setBody(request.body().trim());
        return CommunityMapper.toReplyDto(replyRepository.save(reply));
    }

    private CommunityPost requirePost(Long postId) {
        return postRepository.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("Discussion not found"));
    }

    private Map<Long, Integer> replyCounts() {
        Map<Long, Integer> counts = new HashMap<>();
        for (Object[] row : replyRepository.countRepliesByPost()) {
            counts.put((Long) row[0], ((Number) row[1]).intValue());
        }
        return counts;
    }
}
