package com.bookplatform.user.community.mapper;

import com.bookplatform.common.dto.CommunityPostDto;
import com.bookplatform.common.dto.CommunityReplyDto;
import com.bookplatform.user.community.entity.CommunityPost;
import com.bookplatform.user.community.entity.CommunityReply;

public final class CommunityMapper {

    private CommunityMapper() {
    }

    public static CommunityPostDto toPostDto(CommunityPost post, int replyCount) {
        return new CommunityPostDto(
                post.getId(),
                post.getUserId(),
                post.getUserFullName(),
                post.getTitle(),
                post.getBody(),
                replyCount,
                post.getCreatedAt()
        );
    }

    public static CommunityReplyDto toReplyDto(CommunityReply reply) {
        return new CommunityReplyDto(
                reply.getId(),
                reply.getPostId(),
                reply.getUserId(),
                reply.getUserFullName(),
                reply.getBody(),
                reply.getCreatedAt()
        );
    }
}
