package com.bookplatform.user.community.repository;

import com.bookplatform.user.community.entity.CommunityReply;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CommunityReplyRepository extends JpaRepository<CommunityReply, Long> {

    List<CommunityReply> findByPostIdOrderByCreatedAtAsc(Long postId);

    long countByPostId(Long postId);

    @Query("SELECT r.postId, COUNT(r) FROM CommunityReply r GROUP BY r.postId")
    List<Object[]> countRepliesByPost();
}
