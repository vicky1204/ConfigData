package com.bookplatform.user.config;

import com.bookplatform.common.dto.StoreDto;
import com.bookplatform.common.dto.UserRole;
import com.bookplatform.user.entity.User;
import com.bookplatform.user.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Seeds demo STORE_ADMIN accounts for the sample stores from DataInitializer.
 * DISABLED by default (profile "seed" only) — real stores register via the UI.
 */
@Configuration
@Profile("seed")
public class StoreOwnerDataInitializer {

    private static final Logger log = LoggerFactory.getLogger(StoreOwnerDataInitializer.class);
    private static final String DEFAULT_PASSWORD = "store123";

    private static final Map<String, String> OWNER_NAMES = Map.ofEntries(
            Map.entry("owner.chapterandchai@bookplatform.local", "Ananya Iyer"),
            Map.entry("owner.oldcity@bookplatform.local", "Rahul Mehta"),
            Map.entry("owner.marine@bookplatform.local", "Priya Sharma"),
            Map.entry("owner.heritage@bookplatform.local", "Vikram Singh"),
            Map.entry("owner.lakeview@bookplatform.local", "Meera Nair"),
            Map.entry("owner.riverside@bookplatform.local", "Arjun Patel"),
            Map.entry("owner.hilltop@bookplatform.local", "Kavita Desai"),
            Map.entry("owner.campus@bookplatform.local", "Suresh Reddy")
    );

    @Bean
    CommandLineRunner seedStoreOwners(UserRepository userRepository,
                                      PasswordEncoder passwordEncoder,
                                      RestTemplate restTemplate,
                                      @Value("${bookplatform.services.catalog-url:http://localhost:8086}") String catalogUrl) {
        return args -> {
            List<StoreDto> stores = fetchStores(restTemplate, catalogUrl);
            if (stores.isEmpty()) {
                log.warn("No stores returned from catalog-service; store owner accounts were not seeded");
                return;
            }

            for (StoreDto store : stores) {
                if (store.ownerEmail() == null || store.ownerEmail().isBlank()) {
                    continue;
                }
                String email = store.ownerEmail().toLowerCase();
                User owner = userRepository.findByEmail(email).orElseGet(User::new);
                if (owner.getId() == null) {
                    owner.setEmail(email);
                    owner.setPasswordHash(passwordEncoder.encode(DEFAULT_PASSWORD));
                    owner.setPhone("919999999001");
                }
                owner.setFullName(OWNER_NAMES.getOrDefault(email, store.name() + " Owner"));
                owner.setRole(UserRole.STORE_ADMIN);
                owner.setStoreId(store.id());
                userRepository.save(owner);
            }
        };
    }

    private List<StoreDto> fetchStores(RestTemplate restTemplate, String catalogUrl) {
        try {
            ResponseEntity<List<StoreDto>> response = restTemplate.exchange(
                    catalogUrl + "/api/stores",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<>() {
                    });
            return response.getBody() == null ? List.of() : response.getBody();
        } catch (Exception e) {
            log.warn("Could not fetch stores from {}: {}", catalogUrl, e.getMessage());
            return List.of();
        }
    }
}
