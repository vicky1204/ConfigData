package com.bookplatform.user.service;

import com.bookplatform.common.dto.AccountType;
import com.bookplatform.common.dto.AuthResponse;
import com.bookplatform.common.dto.CreateStoreRequest;
import com.bookplatform.common.dto.LoginRequest;
import com.bookplatform.common.dto.StoreDto;
import com.bookplatform.common.dto.UserRegistrationRequest;
import com.bookplatform.common.dto.UserRole;
import com.bookplatform.user.entity.User;
import com.bookplatform.user.repository.UserRepository;
import com.bookplatform.common.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final RestTemplate restTemplate;
    private final String catalogUrl;

    public UserService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtTokenProvider jwtTokenProvider,
                       RestTemplate restTemplate,
                       @Value("${bookplatform.services.catalog-url:http://localhost:8086}") String catalogUrl) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
        this.restTemplate = restTemplate;
        this.catalogUrl = catalogUrl;
    }

    public AuthResponse register(UserRegistrationRequest request) {
        String email = request.email().trim().toLowerCase();
        String phone = normalizePhone(request.phone());
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email already registered — sign in, or use a different email.");
        }

        AccountType accountType = request.resolvedAccountType();
        Long storeId = null;
        UserRole role = UserRole.USER;

        if (accountType == AccountType.STORE) {
            validateStoreRegistration(request);
            // Call catalog before saving the user so "catalog down" is a clear error
            storeId = createStoreForOwner(request, email, phone).id();
            role = UserRole.STORE_ADMIN;
        }

        User user = new User();
        user.setFullName(request.fullName().trim());
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        user.setPhone(phone);
        user.setRole(role);
        user.setStoreId(storeId);
        userRepository.save(user);
        return buildAuthResponse(user);
    }

    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.email().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));
        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password");
        }
        return buildAuthResponse(user);
    }

    @Transactional
    public void resetPassword(com.bookplatform.common.dto.ResetPasswordRequest request) {
        User user = userRepository.findByEmail(request.email().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("No account found with this email"));
        user.setPasswordHash(passwordEncoder.encode(request.newPassword()));
        userRepository.save(user);
    }

    public User getById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    private void validateStoreRegistration(UserRegistrationRequest request) {
        requireText(request.storeName(), "Store name is required for store registration");
        requireText(request.storeAddressLine(), "Store address is required for store registration");
        requireText(request.storeCity(), "Store city is required for store registration");
        requireText(request.storeState(), "Store state is required for store registration");
        requireText(request.storePincode(), "Store pincode is required for store registration");
    }

    private StoreDto createStoreForOwner(UserRegistrationRequest request, String ownerEmail, String phone) {
        CreateStoreRequest storeRequest = new CreateStoreRequest(
                request.storeName().trim(),
                request.fullName().trim(),
                phone,
                ownerEmail,
                request.storeAddressLine().trim(),
                request.storeCity().trim(),
                request.storeState().trim(),
                request.storePincode().trim(),
                blankToNull(request.storeGoogleMapsUrl()),
                blankToNull(request.storeOpeningHours()),
                blankToNull(request.storePaymentUpiId()),
                null,
                ownerEmail
        );
        try {
            ResponseEntity<StoreDto> response = restTemplate.postForEntity(
                    catalogUrl + "/api/stores", storeRequest, StoreDto.class);
            StoreDto store = response.getBody();
            if (store == null || store.id() == null) {
                throw new IllegalStateException("Catalog-service did not return a store id");
            }
            return store;
        } catch (RestClientException e) {
            throw new IllegalArgumentException(
                    "Could not create store — is catalog-service running on " + catalogUrl + "?", e);
        }
    }

    private AuthResponse buildAuthResponse(User user) {
        String token = jwtTokenProvider.createToken(
                user.getId(), user.getEmail(), user.getRole().name(), user.getStoreId());
        return new AuthResponse(
                token,
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getPhone(),
                user.getRole(),
                user.getStoreId());
    }

    private static void requireText(String value, String message) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(message);
        }
    }

    private static String normalizePhone(String phone) {
        if (phone == null) {
            throw new IllegalArgumentException("Valid WhatsApp phone number required");
        }
        String normalized = phone.trim().replaceAll("[\\s-]", "");
        if (!normalized.matches("^\\+?[0-9]{10,15}$")) {
            throw new IllegalArgumentException(
                    "Valid WhatsApp phone number required (10–15 digits, optional +, no spaces)");
        }
        return normalized;
    }

    private static String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}
