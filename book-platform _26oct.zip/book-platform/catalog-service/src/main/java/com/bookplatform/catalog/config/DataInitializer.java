package com.bookplatform.catalog.config;

import com.bookplatform.catalog.entity.Book;
import com.bookplatform.catalog.entity.Review;
import com.bookplatform.catalog.entity.Store;
import com.bookplatform.catalog.repository.BookRepository;
import com.bookplatform.catalog.repository.InventoryEventRepository;
import com.bookplatform.catalog.repository.ReviewRepository;
import com.bookplatform.catalog.repository.StoreRepository;
import com.bookplatform.catalog.service.InventoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Demo seed data (stores + sample books + reviews).
 * DISABLED by default so real store owners can register and upload their own books.
 * To re-enable demo data temporarily, start with profile: seed
 *   e.g. spring.profiles.active=neon,seed
 */
@Configuration
@Profile("seed")
public class DataInitializer {

    private static final String COVER_STACK =
            "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80";
    private static final String COVER_OPEN =
            "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80";
    private static final String COVER_SHELF =
            "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=600&q=80";
    private static final String COVER_READING =
            "https://images.unsplash.com/photo-1456513080860-7ffa83f2c36a?auto=format&fit=crop&w=600&q=80";
    private static final String COVER_NOTEBOOK =
            "https://images.unsplash.com/photo-1455390582260-0446de1083bb?auto=format&fit=crop&w=600&q=80";

    @Bean
    @Order(1)
    CommandLineRunner seedStores(StoreRepository storeRepository) {
        return args -> {
            if (storeRepository.count() > 0) {
                return;
            }
            storeRepository.save(store("Chapter & Chai Books", "Ananya Iyer",
                    "+91 98765 43210", "hello@chapterandchai.in",
                    "42, 5th Cross, Koramangala 5th Block", "Bengaluru", "Karnataka", "560095",
                    "https://maps.google.com/?q=12.9352,77.6245",
                    "Mon–Sat 10:00 AM – 8:00 PM",
                    "chapterandchai@oksbi", null, "owner.chapterandchai@bookplatform.local"));
            storeRepository.save(store("Old City Reader's Corner", "Rahul Mehta",
                    "+91 98100 11223", "contact@oldcityreads.in",
                    "Shop 7, Chandni Chowk, Near Red Fort", "New Delhi", "Delhi", "110006",
                    "https://maps.google.com/?q=28.6562,77.2410",
                    "Tue–Sun 11:00 AM – 7:30 PM",
                    "oldcityreads@paytm", null, "owner.oldcity@bookplatform.local"));
            storeRepository.save(store("Marine Lines Book Stop", "Priya Sharma",
                    "+91 98200 33445", "marine@bookstop.in",
                    "18, Veer Nariman Road, Churchgate", "Mumbai", "Maharashtra", "400020",
                    "https://maps.google.com/?q=18.9322,72.8267",
                    "Mon–Sat 9:30 AM – 9:00 PM",
                    "marinebookstop@okaxis", null, "owner.marine@bookplatform.local"));
            storeRepository.save(store("Heritage Lane Books", "Vikram Singh",
                    "+91 97850 55667", "info@heritagelane.in",
                    "Hawa Mahal Road, Opposite City Palace", "Jaipur", "Rajasthan", "302002",
                    "https://maps.google.com/?q=26.9239,75.8267",
                    "Daily 10:00 AM – 8:00 PM",
                    "heritagelane@okicici", null, "owner.heritage@bookplatform.local"));
            storeRepository.save(store("Lakeview Pages", "Meera Nair",
                    "+91 98450 77889", "lakeview@pages.in",
                    "221, FC Road, Shivajinagar", "Pune", "Maharashtra", "411005",
                    "https://maps.google.com/?q=18.5285,73.8478",
                    "Mon–Sat 10:00 AM – 8:30 PM",
                    "lakeviewpages@ybl", null, "owner.lakeview@bookplatform.local"));
            storeRepository.save(store("Riverside Book Nook", "Arjun Patel",
                    "+91 98310 99001", "riverside@nook.in",
                    "15, Park Street, Near Oxford Bookstore", "Kolkata", "West Bengal", "700016",
                    "https://maps.google.com/?q=22.5534,88.3530",
                    "Tue–Sun 11:00 AM – 8:00 PM",
                    "riversidenook@oksbi", null, "owner.riverside@bookplatform.local"));
            storeRepository.save(store("Hilltop Stories", "Kavita Desai",
                    "+91 98160 22334", "hilltop@stories.in",
                    "Mall Road, Near Scandal Point", "Shimla", "Himachal Pradesh", "171001",
                    "https://maps.google.com/?q=31.1048,77.1734",
                    "Mon–Sat 10:00 AM – 7:00 PM",
                    "hilltopstories@paytm", null, "owner.hilltop@bookplatform.local"));
            storeRepository.save(store("Campus Corner Books", "Suresh Reddy",
                    "+91 98480 44556", "campus@cornerbooks.in",
                    "Plot 12, HITEC City Main Road, Madhapur", "Hyderabad", "Telangana", "500081",
                    "https://maps.google.com/?q=17.4486,78.3908",
                    "Mon–Sat 9:00 AM – 9:00 PM",
                    "campuscorner@okhdfcbank", null, "owner.campus@bookplatform.local"));
        };
    }

    @Bean
    @Order(2)
    CommandLineRunner backfillStorePaymentDetails(StoreRepository storeRepository) {
        return args -> {
            Map<String, String> upiByStoreName = Map.ofEntries(
                    Map.entry("Chapter & Chai Books", "chapterandchai@oksbi"),
                    Map.entry("Old City Reader's Corner", "oldcityreads@paytm"),
                    Map.entry("Marine Lines Book Stop", "marinebookstop@okaxis"),
                    Map.entry("Heritage Lane Books", "heritagelane@okicici"),
                    Map.entry("Lakeview Pages", "lakeviewpages@ybl"),
                    Map.entry("Riverside Book Nook", "riversidenook@oksbi"),
                    Map.entry("Hilltop Stories", "hilltopstories@paytm"),
                    Map.entry("Campus Corner Books", "campuscorner@okhdfcbank")
            );
            Map<String, String> ownerEmailByStoreName = Map.ofEntries(
                    Map.entry("Chapter & Chai Books", "owner.chapterandchai@bookplatform.local"),
                    Map.entry("Old City Reader's Corner", "owner.oldcity@bookplatform.local"),
                    Map.entry("Marine Lines Book Stop", "owner.marine@bookplatform.local"),
                    Map.entry("Heritage Lane Books", "owner.heritage@bookplatform.local"),
                    Map.entry("Lakeview Pages", "owner.lakeview@bookplatform.local"),
                    Map.entry("Riverside Book Nook", "owner.riverside@bookplatform.local"),
                    Map.entry("Hilltop Stories", "owner.hilltop@bookplatform.local"),
                    Map.entry("Campus Corner Books", "owner.campus@bookplatform.local")
            );
            for (Store store : storeRepository.findAll()) {
                boolean changed = false;
                if (store.getPaymentUpiId() == null || store.getPaymentUpiId().isBlank()) {
                    String upiId = upiByStoreName.get(store.getName());
                    if (upiId != null) {
                        store.setPaymentUpiId(upiId);
                        changed = true;
                    }
                }
                if (store.getOwnerEmail() == null || store.getOwnerEmail().isBlank()) {
                    String ownerEmail = ownerEmailByStoreName.get(store.getName());
                    if (ownerEmail != null) {
                        store.setOwnerEmail(ownerEmail);
                        changed = true;
                    }
                }
                if (changed) {
                    storeRepository.save(store);
                }
            }
        };
    }

    @Bean
    @Order(3)
    CommandLineRunner seedBooks(BookRepository bookRepository, StoreRepository storeRepository) {
        return args -> {
            if (bookRepository.count() > 0) {
                return;
            }
            List<Store> stores = storeRepository.findAllByOrderByNameAsc();
            if (stores.isEmpty()) {
                return;
            }
            int i = 0;
            i = saveBook(bookRepository, stores, i, "Clean Code", "Robert Martin", "978-0132350884", "399",
                    "Technology", "A handbook of agile software craftsmanship.", 20, "English", COVER_STACK);
            i = saveBook(bookRepository, stores, i, "Effective Java", "Joshua Bloch", "978-0134685991", "499",
                    "Technology", "Best practices for the Java platform.", 15, "English", COVER_OPEN);
            i = saveBook(bookRepository, stores, i, "The Pragmatic Programmer", "Hunt & Thomas", "978-0135957059", "450",
                    "Technology", "Your journey to mastery.", 12, "English", COVER_SHELF);
            i = saveBook(bookRepository, stores, i, "Design Patterns", "Gang of Four", "978-0201633610", "550",
                    "Technology", "Elements of reusable object-oriented software.", 10, "English", COVER_READING);
            i = saveBook(bookRepository, stores, i, "Atomic Habits", "James Clear", "978-0735211292", "350",
                    "Self Help", "Tiny changes, remarkable results.", 25, "English", COVER_NOTEBOOK);
            i = saveBook(bookRepository, stores, i, "Deep Work", "Cal Newport", "978-1455586691", "320",
                    "Productivity", "Rules for focused success.", 18, "English", COVER_OPEN);
            i = saveBook(bookRepository, stores, i, "The God of Small Things", "Arundhati Roy", "978-0006550686", "299",
                    "Literature & Fiction", "A lyrical story of childhood and social change in Kerala.", 14, "English", COVER_SHELF);
            i = saveBook(bookRepository, stores, i, "Godan", "Premchand", "978-8170283551", "220",
                    "Literature & Fiction", "A classic Hindi novel about rural Indian life.", 16, "Hindi", COVER_STACK);
            i = saveBook(bookRepository, stores, i, "Raag Darbari", "Shrilal Shukla", "978-8126706984", "250",
                    "Literature & Fiction", "Satirical portrait of village politics in Uttar Pradesh.", 11, "Hindi", COVER_READING);
            i = saveBook(bookRepository, stores, i, "Le Petit Prince", "Antoine de Saint-Exupéry", "978-2070612758", "280",
                    "Children's Books", "A timeless fable about wonder, friendship, and growing up.", 20, "French", COVER_NOTEBOOK);
            i = saveBook(bookRepository, stores, i, "The Murder of Roger Ackroyd", "Agatha Christie", "978-0062073488", "310",
                    "Mystery & Thriller", "A landmark detective novel with a famous twist ending.", 13, "English", COVER_OPEN);
            i = saveBook(bookRepository, stores, i, "The Da Vinci Code", "Dan Brown", "978-0307474278", "340",
                    "Mystery & Thriller", "A fast-paced art-history thriller set across Europe.", 17, "English", COVER_SHELF);
            i = saveBook(bookRepository, stores, i, "Sapiens", "Yuval Noah Harari", "978-0062316097", "420",
                    "History", "A brief history of humankind — from foraging to data empires.", 22, "English", COVER_READING);
            i = saveBook(bookRepository, stores, i, "Ikigai", "García & Miralles", "978-0143130727", "275",
                    "Self Help", "The Japanese secret to a long and happy life.", 30, "English", COVER_NOTEBOOK);
            i = saveBook(bookRepository, stores, i, "Wings of Fire", "A.P.J. Abdul Kalam", "978-8173711466", "199",
                    "Biography", "An autobiography of India's missile man.", 28, "English", COVER_STACK);
            i = saveBook(bookRepository, stores, i, "Malgudi Days", "R.K. Narayan", "978-8185986173", "240",
                    "Literature & Fiction", "Warm, witty stories from a fictional South Indian town.", 19, "English", COVER_OPEN);
            i = saveBook(bookRepository, stores, i, "Madhushala", "Harivansh Rai Bachchan", "978-8126701232", "180",
                    "Poetry", "Iconic Hindi poems of wine, life, and philosophy.", 15, "Hindi", COVER_SHELF);
            saveBook(bookRepository, stores, i, "Harry Potter and the Philosopher's Stone", "J.K. Rowling", "978-0747532699", "399",
                    "Children's Books", "The boy who lived begins his journey at Hogwarts.", 35, "English", COVER_READING);
        };
    }

    @Bean
    @Order(4)
    CommandLineRunner seedReviews(BookRepository bookRepository, ReviewRepository reviewRepository) {
        return args -> {
            if (reviewRepository.count() > 0) {
                return;
            }
            bookRepository.findAll().forEach(book -> {
                switch (book.getTitle()) {
                    case "Clean Code" -> {
                        reviewRepository.save(review(book.getId(), 2L, "Priya Sharma", 5,
                                "Essential reading for every developer. Clear examples and timeless advice."));
                        reviewRepository.save(review(book.getId(), 3L, "Rahul Mehta", 4,
                                "Dense but rewarding. I revisit the refactoring chapters often."));
                    }
                    case "Atomic Habits" -> {
                        reviewRepository.save(review(book.getId(), 4L, "Ananya Iyer", 5,
                                "Practical and motivating — small habits really do compound."));
                        reviewRepository.save(review(book.getId(), 5L, "Vikram Singh", 5,
                                "Finished in a weekend. Already using the 1% rule daily."));
                    }
                    case "The God of Small Things" -> reviewRepository.save(review(book.getId(), 6L, "Meera Nair", 5,
                            "Beautiful prose. A moving portrait of family and society."));
                    case "The Da Vinci Code" -> reviewRepository.save(review(book.getId(), 7L, "Arjun Patel", 4,
                            "A page-turner — perfect for a long train ride."));
                    case "Sapiens" -> reviewRepository.save(review(book.getId(), 8L, "Kavita Desai", 5,
                            "Mind-expanding. Changed how I see history and modern life."));
                    case "Wings of Fire" -> reviewRepository.save(review(book.getId(), 9L, "Suresh Reddy", 5,
                            "Inspiring journey from Rameswaram to Rashtrapati Bhavan."));
                    default -> { }
                }
            });
        };
    }

    @Bean
    @Order(5)
    CommandLineRunner seedInventoryEvents(BookRepository bookRepository,
                                          InventoryEventRepository inventoryEventRepository,
                                          InventoryService inventoryService) {
        return args -> {
            if (inventoryEventRepository.count() > 0) {
                return;
            }
            bookRepository.findAll().forEach(inventoryService::recordBookAdded);
        };
    }

    private int saveBook(BookRepository repository, List<Store> stores, int index,
                         String title, String author, String isbn, String price, String category,
                         String desc, int stock, String language, String imageUrl) {
        Book book = book(title, author, isbn, price, category, desc, stock, language, imageUrl);
        book.setStore(stores.get(index % stores.size()));
        repository.save(book);
        return index + 1;
    }

    private Store store(String name, String contactPerson, String phone, String email,
                        String addressLine, String city, String state, String pincode,
                        String googleMapsUrl, String openingHours,
                        String paymentUpiId, String paymentQrCodeUrl, String ownerEmail) {
        Store store = new Store();
        store.setName(name);
        store.setContactPerson(contactPerson);
        store.setPhone(phone);
        store.setEmail(email);
        store.setAddressLine(addressLine);
        store.setCity(city);
        store.setState(state);
        store.setPincode(pincode);
        store.setGoogleMapsUrl(googleMapsUrl);
        store.setOpeningHours(openingHours);
        store.setPaymentUpiId(paymentUpiId);
        store.setPaymentQrCodeUrl(paymentQrCodeUrl);
        store.setOwnerEmail(ownerEmail);
        return store;
    }

    private Review review(Long bookId, Long userId, String userFullName, int rating, String comment) {
        Review review = new Review();
        review.setBookId(bookId);
        review.setUserId(userId);
        review.setUserFullName(userFullName);
        review.setRating(rating);
        review.setComment(comment);
        return review;
    }

    private Book book(String title, String author, String isbn, String price, String category,
                      String desc, int stock, String language, String imageUrl) {
        Book b = new Book();
        b.setTitle(title);
        b.setAuthor(author);
        b.setIsbn(isbn);
        b.setPrice(new BigDecimal(price));
        b.setCategory(category);
        b.setDescription(desc);
        b.setStock(stock);
        b.setLanguage(language);
        b.setImageUrl(imageUrl);
        return b;
    }
}
