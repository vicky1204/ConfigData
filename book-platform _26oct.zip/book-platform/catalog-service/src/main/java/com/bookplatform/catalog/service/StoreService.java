package com.bookplatform.catalog.service;

import com.bookplatform.catalog.entity.Store;
import com.bookplatform.catalog.mapper.StoreMapper;
import com.bookplatform.catalog.repository.StoreRepository;
import com.bookplatform.common.dto.CreateStoreRequest;
import com.bookplatform.common.dto.StoreDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class StoreService {

    private final StoreRepository storeRepository;

    public StoreService(StoreRepository storeRepository) {
        this.storeRepository = storeRepository;
    }

    public List<StoreDto> listStores() {
        return storeRepository.findAllByOrderByNameAsc().stream()
                .map(StoreMapper::toDto)
                .toList();
    }

    public StoreDto getById(Long id) {
        Store store = storeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Store not found: " + id));
        return StoreMapper.toDto(store);
    }

    @Transactional
    public StoreDto createStore(CreateStoreRequest request) {
        Store store = new Store();
        store.setName(request.name().trim());
        store.setContactPerson(blankToNull(request.contactPerson()));
        store.setPhone(request.phone().trim());
        store.setEmail(blankToNull(request.email()));
        store.setAddressLine(request.addressLine().trim());
        store.setCity(request.city().trim());
        store.setState(request.state().trim());
        store.setPincode(request.pincode().trim());
        String maps = blankToNull(request.googleMapsUrl());
        if (maps == null) {
            String query = store.getAddressLine() + ", " + store.getCity() + ", " + store.getState() + " " + store.getPincode();
            maps = "https://maps.google.com/?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
        }
        store.setGoogleMapsUrl(maps);
        store.setOpeningHours(request.openingHours() == null || request.openingHours().isBlank()
                ? "Mon–Sat 10:00 AM – 8:00 PM"
                : request.openingHours().trim());
        store.setPaymentUpiId(blankToNull(request.paymentUpiId()));
        store.setPaymentQrCodeUrl(blankToNull(request.paymentQrCodeUrl()));
        store.setOwnerEmail(blankToNull(request.ownerEmail()));
        return StoreMapper.toDto(storeRepository.save(store));
    }

    public Store requireStore(Long id) {
        return storeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Store not found: " + id));
    }

    private static String blankToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }
}
