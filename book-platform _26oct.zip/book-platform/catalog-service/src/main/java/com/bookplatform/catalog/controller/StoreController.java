package com.bookplatform.catalog.controller;

import com.bookplatform.catalog.service.CatalogService;
import com.bookplatform.catalog.service.StoreService;
import com.bookplatform.common.dto.BookDto;
import com.bookplatform.common.dto.CreateStoreRequest;
import com.bookplatform.common.dto.StoreDto;
import com.bookplatform.common.openapi.OpenApiConstants;
import com.bookplatform.common.security.JwtTokenProvider;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/stores")
@Tag(name = "Stores", description = "Offline bookstore partners")
public class StoreController {

    private final StoreService storeService;
    private final CatalogService catalogService;
    private final JwtTokenProvider jwtTokenProvider;

    public StoreController(StoreService storeService,
                           CatalogService catalogService,
                           JwtTokenProvider jwtTokenProvider) {
        this.storeService = storeService;
        this.catalogService = catalogService;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @GetMapping
    public List<StoreDto> list() {
        return storeService.listStores();
    }

    @PostMapping
    public ResponseEntity<StoreDto> create(@Valid @RequestBody CreateStoreRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(storeService.createStore(request));
    }

    @GetMapping("/{id}")
    public StoreDto get(@PathVariable("id") Long id) {
        return storeService.getById(id);
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @GetMapping("/{id}/books")
    public List<BookDto> books(@PathVariable("id") Long id,
                               @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        String token = jwtTokenProvider.resolveBearerToken(authorization);
        String role = jwtTokenProvider.getRole(token);
        Long storeId = jwtTokenProvider.getStoreId(token);
        return catalogService.listBooksByStore(id, role, storeId);
    }
}
