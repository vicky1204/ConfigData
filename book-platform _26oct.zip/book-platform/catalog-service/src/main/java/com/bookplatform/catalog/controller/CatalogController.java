package com.bookplatform.catalog.controller;

import com.bookplatform.catalog.service.CatalogService;
import com.bookplatform.common.catalog.BookCsvTemplate;
import com.bookplatform.common.dto.BookDto;
import com.bookplatform.common.dto.BookImportResult;
import com.bookplatform.common.dto.BookPageResponse;
import com.bookplatform.common.dto.CreateBookRequest;
import com.bookplatform.common.dto.UpdateBookRequest;
import com.bookplatform.common.openapi.OpenApiConstants;
import com.bookplatform.common.security.JwtTokenProvider;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/books")
@Tag(name = "Catalog", description = "Book search, details, and stock reservation")
public class CatalogController {

    private final CatalogService catalogService;
    private final JwtTokenProvider jwtTokenProvider;

    public CatalogController(CatalogService catalogService, JwtTokenProvider jwtTokenProvider) {
        this.catalogService = catalogService;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @GetMapping
    public BookPageResponse list(@RequestParam(value = "q", required = false) String q,
                                 @RequestParam(value = "category", required = false) String category,
                                 @RequestParam(value = "language", required = false) String language,
                                 @RequestParam(value = "storeId", required = false) Long storeId,
                                 @RequestParam(value = "page", defaultValue = "0") int page,
                                 @RequestParam(value = "size", defaultValue = "50") int size) {
        return catalogService.searchBooks(q, category, language, storeId, page, size);
    }

    @GetMapping("/recommended")
    public List<BookDto> recommended(@RequestParam(value = "limit", defaultValue = "6") int limit) {
        return catalogService.getRecommendedBooks(limit);
    }

    @GetMapping(value = "/upload/template", produces = "text/csv")
    public ResponseEntity<byte[]> uploadTemplate() {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + BookCsvTemplate.FILENAME + "\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(BookCsvTemplate.content());
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PostMapping("/bulk")
    public BookImportResult bulkCreate(@Valid @RequestBody List<CreateBookRequest> requests,
                                       @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        String token = jwtTokenProvider.resolveBearerToken(authorization);
        String role = jwtTokenProvider.getRole(token);
        Long storeId = jwtTokenProvider.getStoreId(token);
        return catalogService.bulkCreateBooks(requests, role, storeId);
    }

    @GetMapping("/{id}")
    public BookDto get(@PathVariable("id") Long id) {
        return catalogService.getById(id);
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PostMapping
    public ResponseEntity<BookDto> create(@Valid @RequestBody CreateBookRequest request,
                                          Authentication authentication,
                                          @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        String token = jwtTokenProvider.resolveBearerToken(authorization);
        String role = jwtTokenProvider.getRole(token);
        Long storeId = jwtTokenProvider.getStoreId(token);
        return ResponseEntity.status(HttpStatus.CREATED).body(catalogService.createBook(request, role, storeId));
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @PutMapping("/{id}")
    public BookDto update(@PathVariable("id") Long id,
                          @Valid @RequestBody UpdateBookRequest request,
                          @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        String token = jwtTokenProvider.resolveBearerToken(authorization);
        String role = jwtTokenProvider.getRole(token);
        Long storeId = jwtTokenProvider.getStoreId(token);
        return catalogService.updateBook(id, request, role, storeId);
    }

    @SecurityRequirement(name = OpenApiConstants.BEARER_AUTH)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Long id,
                                       @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorization) {
        String token = jwtTokenProvider.resolveBearerToken(authorization);
        String role = jwtTokenProvider.getRole(token);
        Long storeId = jwtTokenProvider.getStoreId(token);
        catalogService.deleteBook(id, role, storeId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/reserve")
    public ResponseEntity<Map<String, String>> reserve(@PathVariable("id") Long id,
                                                       @RequestParam("quantity") int quantity,
                                                       @RequestParam(value = "orderId", required = false) Long orderId) {
        catalogService.reserveStock(id, quantity, orderId);
        return ResponseEntity.ok(Map.of("status", "RESERVED"));
    }

    @PostMapping("/{id}/release")
    public ResponseEntity<Map<String, String>> release(@PathVariable("id") Long id,
                                                       @RequestParam("quantity") int quantity,
                                                       @RequestParam(value = "orderId", required = false) Long orderId) {
        catalogService.releaseStock(id, quantity, orderId);
        return ResponseEntity.ok(Map.of("status", "RETURNED"));
    }
}
