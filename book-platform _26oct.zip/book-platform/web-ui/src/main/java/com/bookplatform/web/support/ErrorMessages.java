package com.bookplatform.web.support;

import feign.FeignException;

/**
 * Keeps user-facing errors short. Prefers the API "detail" field when present.
 */
public final class ErrorMessages {

    private ErrorMessages() {
    }

    public static String resolve(Throwable ex) {
        if (ex == null) {
            return "Something went wrong. Please try again.";
        }

        // Walk the cause chain for the most useful message
        String best = null;
        for (Throwable t = ex; t != null; t = t.getCause()) {
            String msg = t.getMessage();
            if (msg == null || msg.isBlank()) {
                continue;
            }
            String detail = extractDetail(msg);
            if (detail != null) {
                return detail;
            }
            // Prefer short business messages over Feign/wrapper noise
            if (!msg.startsWith("Downstream call failed")
                    && !msg.contains("feign.FeignException")
                    && !msg.contains("Execute exception")) {
                best = msg;
            }
            if (best == null) {
                best = msg;
            }
        }

        if (ex instanceof FeignException feign && feign.status() >= 500) {
            return "A backend service failed. Check that user-service (8085) and catalog-service (8086) are running.";
        }

        if (isTimeout(ex)) {
            return "Request timed out. Ensure catalog-service (8086) and user-service (8085) are running and responsive, then try again.";
        }

        if (isConnectionIssue(ex)) {
            return "Cannot reach backend services. Start catalog-service (8086) and user-service (8085), then try again.";
        }

        return best != null ? best : "Something went wrong. Please try again.";
    }

    public static String titleFor(Throwable ex) {
        return isConnectionIssue(ex) ? "Services unavailable" : "Something went wrong";
    }

    public static String hintFor(Throwable ex) {
        if (isConnectionIssue(ex)) {
            return "Start catalog-service, then user-service, then web-ui.";
        }
        return null;
    }

    public static boolean isServiceUnavailable(Throwable ex) {
        return isConnectionIssue(ex)
                || isTimeout(ex)
                || (ex instanceof FeignException feign && feign.status() >= 500);
    }

    private static boolean isTimeout(Throwable ex) {
        for (Throwable t = ex; t != null; t = t.getCause()) {
            String name = t.getClass().getSimpleName();
            String msg = t.getMessage() == null ? "" : t.getMessage();
            if (name.contains("Timeout")
                    || msg.contains("Read timed out")
                    || msg.contains("timed out")) {
                return true;
            }
        }
        return false;
    }

    private static boolean isConnectionIssue(Throwable ex) {
        for (Throwable t = ex; t != null; t = t.getCause()) {
            String msg = t.getMessage() == null ? "" : t.getMessage();
            String name = t.getClass().getSimpleName();
            if (name.contains("Connect")
                    || msg.contains("Connection refused")
                    || msg.contains("Failed to connect")
                    || msg.contains("Connection timed out")
                    || msg.contains("I/O error")) {
                return true;
            }
        }
        return false;
    }

    private static String extractDetail(String message) {
        if (message == null) {
            return null;
        }
        // "detail":"..." or "detail": "..."
        int key = message.indexOf("\"detail\"");
        if (key < 0) {
            return null;
        }
        int colon = message.indexOf(':', key);
        if (colon < 0) {
            return null;
        }
        int start = message.indexOf('"', colon + 1);
        if (start < 0) {
            return null;
        }
        StringBuilder value = new StringBuilder();
        for (int i = start + 1; i < message.length(); i++) {
            char c = message.charAt(i);
            if (c == '\\' && i + 1 < message.length()) {
                value.append(message.charAt(++i));
                continue;
            }
            if (c == '"') {
                return value.toString();
            }
            value.append(c);
        }
        return null;
    }
}
