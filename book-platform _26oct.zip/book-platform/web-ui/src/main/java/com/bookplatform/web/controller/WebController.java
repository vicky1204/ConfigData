package com.bookplatform.web.controller;

import com.bookplatform.common.TermsAndConditions;
import com.bookplatform.common.catalog.BookCsvParser;
import com.bookplatform.common.catalog.BookCsvTemplate;
import com.bookplatform.common.payment.PaymentQrCodeHelper;
import com.bookplatform.common.dto.*;
import com.bookplatform.web.service.BackendApiService;
import com.bookplatform.web.support.ErrorMessages;
import com.bookplatform.web.support.ErrorRedirect;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Controller
public class WebController {

    private static final Logger log = LoggerFactory.getLogger(WebController.class);

    private final BackendApiService backendApi;

    public WebController(BackendApiService backendApi) {
        this.backendApi = backendApi;
    }

    @GetMapping("/")
    public String home(@RequestParam(value = "q", required = false) String q,
                       @RequestParam(value = "category", required = false) String category,
                       @RequestParam(value = "language", required = false) String language,
                       @RequestParam(value = "storeId", required = false) Long storeId,
                       @RequestParam(value = "view", defaultValue = "grid") String view,
                       @RequestParam(value = "page", defaultValue = "0") int page,
                       HttpSession session,
                       Model model) {
        AuthResponse user = currentUser(session);
        String token = tokenOf(user);
        addUserAttributes(model, user);
        model.addAttribute("query", q == null ? "" : q);
        model.addAttribute("selectedCategory", category == null ? "" : category);
        model.addAttribute("selectedLanguage", language == null ? "" : language);
        model.addAttribute("selectedStoreId", storeId);
        model.addAttribute("viewMode", "list".equalsIgnoreCase(view) ? "list" : "grid");
        boolean showRecommended = page == 0
                && (q == null || q.isBlank())
                && (category == null || category.isBlank())
                && (language == null || language.isBlank())
                && storeId == null;
        model.addAttribute("showRecommended", showRecommended);
        try {
            BookPageResponse bookPage = backendApi.browseBooks(q, category, language, storeId, page, token);
            model.addAttribute("bookPage", bookPage);
            model.addAttribute("books", bookPage.getContent());
            model.addAttribute("categories", bookPage.getCategories());
            model.addAttribute("languages", bookPage.getLanguages());
            model.addAttribute("stores", backendApi.listStores(token));
            if (showRecommended) {
                model.addAttribute("recommendedBooks", backendApi.getRecommendedBooks(6, token));
            } else {
                model.addAttribute("recommendedBooks", Collections.emptyList());
            }
        } catch (Exception e) {
            log.warn("Failed to load books from catalog-service", e);
            model.addAttribute("bookPage", new BookPageResponse(Collections.emptyList(), 0, 50, 0, 0,
                    Collections.emptyList(), Collections.emptyList()));
            model.addAttribute("books", Collections.emptyList());
            model.addAttribute("categories", Collections.emptyList());
            model.addAttribute("languages", Collections.emptyList());
            model.addAttribute("stores", Collections.emptyList());
            model.addAttribute("recommendedBooks", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "home";
    }

    @GetMapping("/login")
    public String loginPage(@RequestParam(value = "redirect", required = false) String redirect, Model model) {
        if (safeRedirect(redirect) != null) {
            model.addAttribute("redirect", redirect);
        }
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("email") String email,
                        @RequestParam("password") String password,
                        @RequestParam(value = "redirect", required = false) String redirect,
                        HttpSession session,
                        RedirectAttributes redirectAttributes) {
        try {
            AuthResponse auth = backendApi.login(new LoginRequest(email, password));
            session.setAttribute("user", auth);
            String target = safeRedirect(redirect);
            if (target != null) {
                return "redirect:" + target;
            }
            if (auth.isStoreAdmin()) {
                return "redirect:/store/books";
            }
            if (auth.isAdmin()) {
                return "redirect:/admin/dashboard";
            }
            return "redirect:/";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/login", "Try again");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/login";
        }
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam("fullName") String fullName,
                           @RequestParam("email") String email,
                           @RequestParam("password") String password,
                           @RequestParam("phone") String phone,
                           @RequestParam(value = "accountType", defaultValue = "USER") String accountType,
                           @RequestParam(value = "storeName", required = false) String storeName,
                           @RequestParam(value = "storeAddressLine", required = false) String storeAddressLine,
                           @RequestParam(value = "storeCity", required = false) String storeCity,
                           @RequestParam(value = "storeState", required = false) String storeState,
                           @RequestParam(value = "storePincode", required = false) String storePincode,
                           @RequestParam(value = "storeGoogleMapsUrl", required = false) String storeGoogleMapsUrl,
                           @RequestParam(value = "storeOpeningHours", required = false) String storeOpeningHours,
                           @RequestParam(value = "storePaymentUpiId", required = false) String storePaymentUpiId,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        try {
            AccountType type = "STORE".equalsIgnoreCase(accountType) ? AccountType.STORE : AccountType.USER;
            AuthResponse auth = backendApi.register(new UserRegistrationRequest(
                    fullName, email, password, phone, type,
                    storeName, storeAddressLine, storeCity, storeState, storePincode,
                    storeGoogleMapsUrl, storeOpeningHours, storePaymentUpiId));
            session.setAttribute("user", auth);
            if (auth.isStoreAdmin()) {
                redirectAttributes.addFlashAttribute("success",
                        "Store registered. You can add books to your catalog now.");
                return "redirect:/store/books";
            }
            return "redirect:/";
        } catch (Exception e) {
            // Registration failures (validation, duplicate email, catalog down) stay on the form.
            log.warn("Registration failed for {}: {}", email, e.toString());
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/register";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/forgot-password")
    public String forgotPasswordPage() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String resetPassword(@RequestParam("email") String email,
                                @RequestParam("newPassword") String newPassword,
                                @RequestParam("confirmPassword") String confirmPassword,
                                RedirectAttributes redirectAttributes) {
        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Passwords do not match");
            return "redirect:/forgot-password";
        }
        if (newPassword.length() < 6) {
            redirectAttributes.addFlashAttribute("error", "Password must be at least 6 characters");
            return "redirect:/forgot-password";
        }
        try {
            backendApi.resetPassword(new ResetPasswordRequest(email, newPassword));
            redirectAttributes.addFlashAttribute("success", "Password updated. You can sign in now.");
            return "redirect:/login";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/forgot-password", "Try again");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/forgot-password";
        }
    }

    @GetMapping("/books/{id}")
    public String bookDetail(@PathVariable("id") Long id,
                             HttpSession session,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        AuthResponse user = currentUser(session);
        String token = tokenOf(user);

        try {
            BookDto book = backendApi.getBook(id, token);
            List<ReviewDto> reviews = backendApi.getReviews(id, token);
            ReviewDto userReview = null;
            if (user != null) {
                userReview = reviews.stream()
                        .filter(review -> review.userId().equals(user.userId()))
                        .findFirst()
                        .orElse(null);
            }

            addUserAttributes(model, user);
            model.addAttribute("book", book);
            model.addAttribute("reviews", reviews);
            model.addAttribute("userReview", userReview);
            return "book-detail";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to books");
            }
            return ErrorRedirect.toErrorPage(
                    redirectAttributes,
                    "Book unavailable",
                    ErrorMessages.resolve(e),
                    null,
                    "/",
                    "Back to books"
            );
        }
    }

    @PostMapping("/books/{id}/reviews")
    public String submitReview(@PathVariable("id") Long id,
                               @RequestParam("rating") int rating,
                               @RequestParam(value = "comment", required = false) String comment,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) {
            return "redirect:/login?redirect=/books/" + id;
        }

        try {
            backendApi.submitReview(id,
                    new CreateReviewRequest(rating, comment == null ? "" : comment, user.fullName()),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Your review has been saved.");
            return "redirect:/books/" + id;
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/books/" + id, "Back to book");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/books/" + id;
        }
    }

    @GetMapping("/books/{id}/checkout")
    public String checkoutPage(@PathVariable("id") Long id,
                               HttpSession session,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) {
            return "redirect:/login?redirect=/books/" + id + "/checkout";
        }

        try {
            BookDto book = backendApi.getBook(id, user.token());
            BigDecimal checkoutAmount = TermsAndConditions.checkoutAmountForUnitPrice(book.price());
            BigDecimal platformFee = TermsAndConditions.platformFeeForUnitPrice(book.price());
            BigDecimal refundPreview = TermsAndConditions.refundForUnitPrice(book.price());

            model.addAttribute("user", user);
            model.addAttribute("isAdmin", user.isAdmin());
            model.addAttribute("book", book);
            model.addAttribute("terms", TermsAndConditions.TEXT);
            model.addAttribute("checkoutAmount", checkoutAmount);
            model.addAttribute("platformFee", platformFee);
            model.addAttribute("refundPreview", refundPreview);
            model.addAttribute("checkoutPaymentPercent", TermsAndConditions.CHECKOUT_PAYMENT_PERCENT);
            if (book.store() != null) {
                // For now QR encodes platform fee only (5%); 90% checkout amount stays struck out in UI.
                String paymentQrUrl = PaymentQrCodeHelper.storePaymentQrUrl(
                        book.store().paymentQrCodeUrl(),
                        book.store().paymentUpiId(),
                        book.store().name(),
                        platformFee);
                model.addAttribute("paymentQrUrl", paymentQrUrl);
                model.addAttribute("paymentUpiId", book.store().paymentUpiId());
                model.addAttribute("storeName", book.store().name());
                model.addAttribute("hasStorePayment", paymentQrUrl != null);
            } else {
                model.addAttribute("hasStorePayment", false);
            }
            return "checkout";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to books");
            }
            return ErrorRedirect.toErrorPage(
                    redirectAttributes,
                    "Book unavailable",
                    ErrorMessages.resolve(e),
                    null,
                    "/",
                    "Back to books"
            );
        }
    }

    @PostMapping("/books/{id}/checkout")
    public String checkout(@PathVariable("id") Long id,
                           @RequestParam("quantity") int quantity,
                           @RequestParam(value = "termsAccepted", required = false) Boolean termsAccepted,
                           @RequestParam(value = "skipPayment", required = false) Boolean skipPayment,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) {
            return "redirect:/login?redirect=/books/" + id + "/checkout";
        }

        try {
            boolean accepted = termsAccepted != null && termsAccepted;
            boolean paymentSkipped = skipPayment != null && skipPayment;
            OrderResponse order = backendApi.checkout(user.userId(),
                    new CheckoutRequest(id, quantity, accepted, paymentSkipped,
                            user.fullName(), user.phone()),
                    user.token());
            String successMessage = paymentSkipped
                    ? "Order placed without payment (beta). Refund after return: INR " + order.refundAmount()
                    : "Order placed! Paid INR " + order.amountPaid() + ". Refund after return: INR " + order.refundAmount();
            redirectAttributes.addFlashAttribute("success", successMessage);
            return "redirect:/orders";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/books/" + id + "/checkout", "Back to checkout");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/books/" + id + "/checkout";
        }
    }

    @GetMapping("/community")
    public String community(HttpSession session, Model model) {
        AuthResponse user = currentUser(session);
        addUserAttributes(model, user);
        try {
            model.addAttribute("posts", backendApi.listCommunityPosts());
        } catch (Exception e) {
            log.warn("Failed to load community posts", e);
            model.addAttribute("posts", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "community";
    }

    @PostMapping("/community")
    public String createCommunityPost(@RequestParam("title") String title,
                                      @RequestParam("body") String body,
                                      HttpSession session,
                                      RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "Please sign in to start a discussion.");
            return "redirect:/login?redirect=/community";
        }

        try {
            CommunityPostDto post = backendApi.createCommunityPost(
                    new CreateCommunityPostRequest(title, body, user.fullName()), user.token());
            redirectAttributes.addFlashAttribute("success", "Your discussion has been posted.");
            return "redirect:/community/" + post.id();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/community";
        }
    }

    @GetMapping("/community/{id}")
    public String communityPost(@PathVariable("id") Long id,
                                HttpSession session,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        AuthResponse user = currentUser(session);
        addUserAttributes(model, user);
        try {
            CommunityPostDetailDto detail = backendApi.getCommunityPost(id);
            model.addAttribute("detail", detail);
            model.addAttribute("post", detail.post());
            model.addAttribute("replies", detail.replies());
            return "community-post";
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/community", "Back to community");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/community";
        }
    }

    @PostMapping("/community/{id}/replies")
    public String createCommunityReply(@PathVariable("id") Long id,
                                       @RequestParam("body") String body,
                                       HttpSession session,
                                       RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "Please sign in to reply.");
            return "redirect:/login?redirect=/community/" + id;
        }

        try {
            backendApi.createCommunityReply(id,
                    new CreateCommunityReplyRequest(body, user.fullName()), user.token());
            redirectAttributes.addFlashAttribute("success", "Your reply has been posted.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
        }
        return "redirect:/community/" + id;
    }

    @GetMapping("/orders")
    public String orders(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        model.addAttribute("user", user);
        model.addAttribute("isAdmin", user.isAdmin());
        try {
            model.addAttribute("orders", backendApi.userOrders(user.userId(), user.token()));
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/orders", "Try again");
            }
            model.addAttribute("orders", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "orders";
    }

    @PostMapping("/orders/{orderId}/deliver")
    public String deliver(@PathVariable("orderId") Long orderId,
                          HttpSession session,
                          RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            backendApi.deliverOrder(orderId, user.token());
            redirectAttributes.addFlashAttribute("success",
                    "Order marked DELIVERED. WhatsApp notification sent (check notification-service logs).");
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/orders", "Back to orders");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
        }
        return "redirect:/orders";
    }

    @PostMapping("/orders/{orderId}/return")
    public String returnOrder(@PathVariable("orderId") Long orderId,
                              HttpSession session,
                              RedirectAttributes redirectAttributes) {
        AuthResponse user = requireUser(session);
        if (user == null) return "redirect:/login";

        try {
            OrderResponse order = backendApi.returnOrder(orderId, user.token());
            redirectAttributes.addFlashAttribute("success",
                    "Book returned to " + order.storeName() + ". Refund of INR " + order.refundAmount() + " processed.");
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/orders", "Back to orders");
            }
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
        }
        return "redirect:/orders";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";

        model.addAttribute("user", user);
        model.addAttribute("isAdmin", true);
        try {
            model.addAttribute("dashboard", backendApi.getAdminDashboard(user.token()));
            model.addAttribute("inventoryEvents", backendApi.getRecentInventoryEvents(user.token()));
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to browse");
            }
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "admin-dashboard";
    }

    @GetMapping("/admin/books")
    public String adminBooksPage(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";
        model.addAttribute("user", user);
        model.addAttribute("isAdmin", true);
        try {
            model.addAttribute("stores", backendApi.listStores(user.token()));
            model.addAttribute("books", backendApi.browseBooks(null, null, null, null, 0, user.token()).getContent());
        } catch (Exception e) {
            model.addAttribute("stores", Collections.emptyList());
            model.addAttribute("books", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "admin-books";
    }

    @GetMapping("/admin/books/{id}/edit")
    public String adminEditBookPage(@PathVariable("id") Long id,
                                    HttpSession session,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto book = backendApi.getBook(id, user.token());
            model.addAttribute("user", user);
            model.addAttribute("isAdmin", true);
            model.addAttribute("book", book);
            model.addAttribute("stores", backendApi.listStores(user.token()));
            model.addAttribute("showStoreSelect", true);
            model.addAttribute("formAction", "/admin/books/" + id + "/edit");
            model.addAttribute("cancelUrl", "/admin/books");
            model.addAttribute("pageTitle", "Edit book");
            model.addAttribute("pageSubtitle", "Update catalog details for this title.");
            return "book-edit";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/admin/books";
        }
    }

    @PostMapping("/admin/books/{id}/edit")
    public String adminUpdateBook(@PathVariable("id") Long id,
                                  @RequestParam("title") String title,
                                  @RequestParam("author") String author,
                                  @RequestParam("isbn") String isbn,
                                  @RequestParam("price") BigDecimal price,
                                  @RequestParam("category") String category,
                                  @RequestParam("description") String description,
                                  @RequestParam("stock") int stock,
                                  @RequestParam("language") String language,
                                  @RequestParam("storeId") Long storeId,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto existing = backendApi.getBook(id, user.token());
            backendApi.updateBook(id, new UpdateBookRequest(title, author, isbn, price, category, description, stock,
                            language, existing.imageUrl(), storeId),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Book updated successfully.");
            return "redirect:/admin/books";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/admin/books/" + id + "/edit";
        }
    }

    @PostMapping("/admin/books")
    public String createBook(@RequestParam("title") String title,
                             @RequestParam("author") String author,
                             @RequestParam("isbn") String isbn,
                             @RequestParam("price") BigDecimal price,
                             @RequestParam("category") String category,
                             @RequestParam("description") String description,
                             @RequestParam("stock") int stock,
                             @RequestParam("storeId") Long storeId,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            backendApi.createBook(new CreateBookRequest(title, author, isbn, price, category, description, stock,
                            "English", "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",
                            storeId),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Book added successfully.");
            return "redirect:/";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/admin/books";
        }
    }

    @GetMapping("/store/books")
    public String storeBooksPage(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";

        model.addAttribute("user", user);
        model.addAttribute("isAdmin", false);
        model.addAttribute("isStoreAdmin", true);
        try {
            StoreDto store = backendApi.getStore(user.storeId(), user.token());
            model.addAttribute("store", store);
            model.addAttribute("books", backendApi.listStoreBooks(user.storeId(), user.token()));
        } catch (Exception e) {
            if (ErrorMessages.isServiceUnavailable(e)) {
                return ErrorRedirect.toErrorPage(redirectAttributes, e, "/", "Back to browse");
            }
            model.addAttribute("books", Collections.emptyList());
            model.addAttribute("error", ErrorMessages.resolve(e));
        }
        return "store-books";
    }

    @GetMapping("/store/books/new")
    public String storeAddBookPage(HttpSession session, Model model) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";
        addUserAttributes(model, user);
        return "store-book-add";
    }

    @PostMapping("/store/books")
    public String createStoreBook(@RequestParam("title") String title,
                                  @RequestParam("author") String author,
                                  @RequestParam("isbn") String isbn,
                                  @RequestParam("price") BigDecimal price,
                                  @RequestParam("category") String category,
                                  @RequestParam("description") String description,
                                  @RequestParam("stock") int stock,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            backendApi.createBook(new CreateBookRequest(title, author, isbn, price, category, description, stock,
                            "English", "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80",
                            user.storeId()),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Book added to your store.");
            return "redirect:/store/books";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/store/books/new";
        }
    }

    @PostMapping("/store/books/{id}/delete")
    public String deleteStoreBook(@PathVariable("id") Long id,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto book = backendApi.getBook(id, user.token());
            if (book.store() == null || !user.storeId().equals(book.store().id())) {
                redirectAttributes.addFlashAttribute("error", "You can only delete books in your store.");
                return "redirect:/store/books";
            }
            backendApi.deleteBook(id, user.token());
            redirectAttributes.addFlashAttribute("success", "Book deleted from your store.");
            return "redirect:/store/books";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/store/books";
        }
    }

    @GetMapping("/store/books/{id}/edit")
    public String storeEditBookPage(@PathVariable("id") Long id,
                                    HttpSession session,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto book = backendApi.getBook(id, user.token());
            if (book.store() == null || !user.storeId().equals(book.store().id())) {
                redirectAttributes.addFlashAttribute("error", "You can only edit books in your store.");
                return "redirect:/store/books";
            }
            model.addAttribute("user", user);
            model.addAttribute("isStoreAdmin", true);
            model.addAttribute("book", book);
            model.addAttribute("showStoreSelect", false);
            model.addAttribute("formAction", "/store/books/" + id + "/edit");
            model.addAttribute("cancelUrl", "/store/books");
            model.addAttribute("pageTitle", "Edit store book");
            model.addAttribute("pageSubtitle", "Update this title in your store catalog.");
            return "book-edit";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/store/books";
        }
    }

    @PostMapping("/store/books/{id}/edit")
    public String storeUpdateBook(@PathVariable("id") Long id,
                                  @RequestParam("title") String title,
                                  @RequestParam("author") String author,
                                  @RequestParam("isbn") String isbn,
                                  @RequestParam("price") BigDecimal price,
                                  @RequestParam("category") String category,
                                  @RequestParam("description") String description,
                                  @RequestParam("stock") int stock,
                                  @RequestParam("language") String language,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";

        try {
            BookDto existing = backendApi.getBook(id, user.token());
            backendApi.updateBook(id, new UpdateBookRequest(title, author, isbn, price, category, description, stock,
                            language, existing.imageUrl(), user.storeId()),
                    user.token());
            redirectAttributes.addFlashAttribute("success", "Book updated successfully.");
            return "redirect:/store/books";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:/store/books/" + id + "/edit";
        }
    }

    @GetMapping("/admin/books/upload")
    public String adminBookUploadPage(HttpSession session, Model model) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";
        populateUploadPage(model, user, true, "/admin/books/upload", "/admin/books/upload/template", "/admin/books");
        return "book-upload";
    }

    @GetMapping("/admin/books/upload/template")
    public ResponseEntity<byte[]> adminBookUploadTemplate() {
        return downloadBookUploadTemplate();
    }

    @PostMapping("/admin/books/upload")
    public String adminBookUpload(@RequestParam("file") MultipartFile file,
                                  HttpSession session,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        AuthResponse user = requirePlatformAdmin(session);
        if (user == null) return "redirect:/login";
        return processBookUpload(file, user, null, true, "/admin/books/upload",
                "/admin/books/upload/template", "/admin/books", model, redirectAttributes);
    }

    @GetMapping("/store/books/upload")
    public String storeBookUploadPage(HttpSession session, Model model) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";
        populateUploadPage(model, user, false, "/store/books/upload", "/store/books/upload/template", "/store/books");
        return "book-upload";
    }

    @GetMapping("/store/books/upload/template")
    public ResponseEntity<byte[]> storeBookUploadTemplate() {
        return downloadBookUploadTemplate();
    }

    @PostMapping("/store/books/upload")
    public String storeBookUpload(@RequestParam("file") MultipartFile file,
                                  HttpSession session,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        AuthResponse user = requireStoreAdmin(session);
        if (user == null) return "redirect:/login";
        return processBookUpload(file, user, user.storeId(), false, "/store/books/upload",
                "/store/books/upload/template", "/store/books", model, redirectAttributes);
    }

    private AuthResponse currentUser(HttpSession session) {
        return (AuthResponse) session.getAttribute("user");
    }

    private AuthResponse requireUser(HttpSession session) {
        return currentUser(session);
    }

    private AuthResponse requirePlatformAdmin(HttpSession session) {
        AuthResponse user = currentUser(session);
        if (user == null || !user.isAdmin()) {
            return null;
        }
        return user;
    }

    private AuthResponse requireStoreAdmin(HttpSession session) {
        AuthResponse user = currentUser(session);
        if (user == null || !user.isStoreAdmin() || user.storeId() == null) {
            return null;
        }
        return user;
    }

    private void addUserAttributes(Model model, AuthResponse user) {
        model.addAttribute("user", user);
        model.addAttribute("isAdmin", user != null && user.isAdmin());
        model.addAttribute("isStoreAdmin", user != null && user.isStoreAdmin());
        model.addAttribute("storeId", user != null ? user.storeId() : null);
    }

    private String tokenOf(AuthResponse user) {
        return user != null ? user.token() : null;
    }

    private String safeRedirect(String redirect) {
        if (redirect == null || redirect.isBlank() || !redirect.startsWith("/") || redirect.startsWith("//")) {
            return null;
        }
        return redirect;
    }

    private ResponseEntity<byte[]> downloadBookUploadTemplate() {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + BookCsvTemplate.FILENAME + "\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(BookCsvTemplate.content());
    }

    private void populateUploadPage(Model model,
                                    AuthResponse user,
                                    boolean showStoreColumn,
                                    String uploadUrl,
                                    String templateUrl,
                                    String cancelUrl) {
        model.addAttribute("user", user);
        model.addAttribute("isAdmin", user.isAdmin());
        model.addAttribute("isStoreAdmin", user.isStoreAdmin());
        model.addAttribute("showStoreColumn", showStoreColumn);
        model.addAttribute("uploadUrl", uploadUrl);
        model.addAttribute("templateUrl", templateUrl);
        model.addAttribute("cancelUrl", cancelUrl);
        model.addAttribute("pageTitle", showStoreColumn ? "Bulk upload books" : "Upload books to your store");
        model.addAttribute("pageSubtitle", showStoreColumn
                ? "Import many books at once for any partner store."
                : "Import many books at once into your store catalog.");
    }

    private String processBookUpload(MultipartFile file,
                                     AuthResponse user,
                                     Long defaultStoreId,
                                     boolean showStoreColumn,
                                     String uploadUrl,
                                     String templateUrl,
                                     String cancelUrl,
                                     Model model,
                                     RedirectAttributes redirectAttributes) {
        if (file == null || file.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please choose a CSV file to upload.");
            return "redirect:" + uploadUrl;
        }

        try {
            BookCsvParser.ParseResult parsed = BookCsvParser.parse(file.getInputStream(), defaultStoreId);
            if (parsed.books().isEmpty() && parsed.errors().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "No book rows found in the uploaded file.");
                return "redirect:" + uploadUrl;
            }

            BookImportResult result = parsed.books().isEmpty()
                    ? new BookImportResult(0, 0, List.of())
                    : backendApi.bulkImportBooks(parsed.books(), user.token());

            List<String> allErrors = new ArrayList<>(parsed.errors());
            allErrors.addAll(result.errors());

            if (result.imported() > 0) {
                redirectAttributes.addFlashAttribute("success",
                        "Imported " + result.imported() + " book(s) successfully.");
            }
            if (!allErrors.isEmpty()) {
                if (result.imported() == 0) {
                    model.addAttribute("error", "No books were imported. Please fix the issues below and try again.");
                }
                model.addAttribute("importErrors", allErrors);
                populateUploadPage(model, user, showStoreColumn, uploadUrl, templateUrl, cancelUrl);
                return "book-upload";
            }
            return "redirect:" + cancelUrl;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", ErrorMessages.resolve(e));
            return "redirect:" + uploadUrl;
        }
    }
}
