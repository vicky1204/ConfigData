package com.bookplatform.common.dto;

public record AuthResponse(
        String token,
        Long userId,
        String fullName,
        String email,
        String phone,
        UserRole role,
        Long storeId
) implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    public boolean isAdmin() {
        return role == UserRole.ADMIN;
    }

    public boolean isStoreAdmin() {
        return role == UserRole.STORE_ADMIN;
    }

    public boolean canManageCatalog() {
        return isAdmin() || isStoreAdmin();
    }
}
