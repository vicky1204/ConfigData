package com.bookplatform.common.catalog;

import com.bookplatform.common.dto.CreateBookRequest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class BookCsvParser {

    public record ParseResult(List<CreateBookRequest> books, List<String> errors) {
    }

    private BookCsvParser() {
    }

    public static ParseResult parse(InputStream inputStream, Long defaultStoreId) throws IOException {
        List<CreateBookRequest> books = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String header = reader.readLine();
            if (header == null || header.isBlank()) {
                errors.add("File is empty");
                return new ParseResult(books, errors);
            }

            String line;
            int lineNumber = 1;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.isBlank()) {
                    continue;
                }
                try {
                    books.add(parseRow(line, lineNumber, defaultStoreId));
                } catch (IllegalArgumentException e) {
                    errors.add("Row " + lineNumber + ": " + e.getMessage());
                }
            }
        }
        return new ParseResult(books, errors);
    }

    private static CreateBookRequest parseRow(String line, int lineNumber, Long defaultStoreId) {
        List<String> columns = splitCsvLine(line);
        if (columns.size() < 9) {
            throw new IllegalArgumentException("expected at least 9 columns (storeId is optional)");
        }

        String title = required(columns, 0, "title");
        String author = required(columns, 1, "author");
        String isbn = required(columns, 2, "isbn");
        BigDecimal price = parsePrice(required(columns, 3, "price"));
        String category = required(columns, 4, "category");
        String description = required(columns, 5, "description");
        int stock = parseStock(required(columns, 6, "stock"));
        String language = required(columns, 7, "language");
        String imageUrl = optional(columns, 8);
        if (imageUrl == null || imageUrl.isBlank()) {
            imageUrl = BookCsvTemplate.DEFAULT_IMAGE_URL;
        }
        Long storeId = parseStoreId(optional(columns, 9), defaultStoreId, lineNumber);

        return new CreateBookRequest(title, author, isbn, price, category, description, stock, language, imageUrl, storeId);
    }

    private static Long parseStoreId(String value, Long defaultStoreId, int lineNumber) {
        if (value == null || value.isBlank()) {
            if (defaultStoreId == null) {
                throw new IllegalArgumentException("storeId is required on row " + lineNumber);
            }
            return defaultStoreId;
        }
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("invalid storeId: " + value);
        }
    }

    private static int parseStock(String value) {
        try {
            int stock = Integer.parseInt(value.trim());
            if (stock < 0) {
                throw new IllegalArgumentException("stock cannot be negative");
            }
            return stock;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("invalid stock: " + value);
        }
    }

    private static BigDecimal parsePrice(String value) {
        try {
            BigDecimal price = new BigDecimal(value.trim());
            if (price.compareTo(new BigDecimal("0.01")) < 0) {
                throw new IllegalArgumentException("price must be at least 0.01");
            }
            return price;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("invalid price: " + value);
        }
    }

    private static String required(List<String> columns, int index, String name) {
        if (index >= columns.size()) {
            throw new IllegalArgumentException("missing " + name);
        }
        String value = columns.get(index).trim();
        if (value.isEmpty()) {
            throw new IllegalArgumentException("missing " + name);
        }
        return value;
    }

    private static String optional(List<String> columns, int index) {
        if (index >= columns.size()) {
            return null;
        }
        return columns.get(index).trim();
    }

    static List<String> splitCsvLine(String line) {
        List<String> values = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (ch == ',' && !inQuotes) {
                values.add(current.toString().trim());
                current.setLength(0);
            } else {
                current.append(ch);
            }
        }
        values.add(current.toString().trim());
        return values;
    }
}
