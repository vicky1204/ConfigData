package com.bookplatform.common.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateStoreRequest(
        @NotBlank @Size(max = 200) String name,
        String contactPerson,
        @NotBlank @Size(max = 30) String phone,
        String email,
        @NotBlank @Size(max = 500) String addressLine,
        @NotBlank @Size(max = 100) String city,
        @NotBlank @Size(max = 100) String state,
        @NotBlank @Size(max = 20) String pincode,
        String googleMapsUrl,
        String openingHours,
        String paymentUpiId,
        String paymentQrCodeUrl,
        String ownerEmail
) {
}
