package com.bookplatform.common.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Registration payload. Use {@link AccountType#USER} for buyers (checkout)
 * or {@link AccountType#STORE} for store owners (manage their own catalog).
 */
public record UserRegistrationRequest(
        @NotBlank String fullName,
        @NotBlank @Email String email,
        @NotBlank @Size(min = 6, max = 100) String password,
        @NotBlank
        @Pattern(regexp = "^\\+?[0-9][0-9\\s-]{8,18}[0-9]$",
                message = "Valid WhatsApp phone number required (10–15 digits)")
        String phone,
        AccountType accountType,
        String storeName,
        String storeAddressLine,
        String storeCity,
        String storeState,
        String storePincode,
        String storeGoogleMapsUrl,
        String storeOpeningHours,
        String storePaymentUpiId
) {
    public AccountType resolvedAccountType() {
        return accountType == null ? AccountType.USER : accountType;
    }

    /** Convenience constructor for buyer (USER) registration. */
    public UserRegistrationRequest(String fullName, String email, String password, String phone) {
        this(fullName, email, password, phone, AccountType.USER,
                null, null, null, null, null, null, null, null);
    }
}
