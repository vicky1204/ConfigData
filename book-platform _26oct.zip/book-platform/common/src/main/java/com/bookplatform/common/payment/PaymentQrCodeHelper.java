package com.bookplatform.common.payment;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public final class PaymentQrCodeHelper {

    private static final String QR_SERVICE_BASE =
            "https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=";

    private PaymentQrCodeHelper() {
    }

    public static String upiPayUri(String upiId, String payeeName, BigDecimal amount) {
        if (upiId == null || upiId.isBlank()) {
            return null;
        }
        String payee = payeeName == null || payeeName.isBlank() ? "Book Store" : payeeName;
        BigDecimal payable = amount == null
                ? BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
                : amount.setScale(2, RoundingMode.HALF_UP);
        return "upi://pay?pa=" + encode(upiId.trim())
                + "&pn=" + encode(payee)
                + "&am=" + payable.toPlainString()
                + "&cu=INR";
    }

    public static String qrImageUrl(String payload) {
        if (payload == null || payload.isBlank()) {
            return null;
        }
        return QR_SERVICE_BASE + encode(payload);
    }

    public static String storePaymentQrUrl(String paymentQrCodeUrl, String paymentUpiId,
                                           String storeName, BigDecimal amount) {
        if (paymentQrCodeUrl != null && !paymentQrCodeUrl.isBlank()) {
            return paymentQrCodeUrl.trim();
        }
        return qrImageUrl(upiPayUri(paymentUpiId, storeName, amount));
    }

    private static String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
