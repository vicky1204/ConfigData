package com.bookplatform.common.catalog;

import java.nio.charset.StandardCharsets;

public final class BookCsvTemplate {

    public static final String HEADER =
            "title,author,isbn,price,category,description,stock,language,imageUrl,storeId";

    public static final String SAMPLE_ROW =
            "\"Clean Code\",\"Robert Martin\",\"978-0132350884\",399,Technology,"
                    + "\"A handbook of agile software craftsmanship.\",10,English,"
                    + "\"https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80\",1";

    public static final String DEFAULT_IMAGE_URL =
            "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80";

    public static final String FILENAME = "book-upload-template.csv";

    private BookCsvTemplate() {
    }

    public static byte[] content() {
        String csv = HEADER + System.lineSeparator()
                + SAMPLE_ROW + System.lineSeparator();
        return csv.getBytes(StandardCharsets.UTF_8);
    }
}
