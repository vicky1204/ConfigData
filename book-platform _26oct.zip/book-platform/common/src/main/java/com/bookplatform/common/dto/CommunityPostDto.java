package com.bookplatform.common.dto;

import java.time.Instant;

public record CommunityPostDto(
        Long id,
        Long userId,
        String userFullName,
        String title,
        String body,
        int replyCount,
        Instant createdAt
) {
}
