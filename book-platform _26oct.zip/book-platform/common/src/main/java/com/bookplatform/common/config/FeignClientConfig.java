package com.bookplatform.common.config;

import feign.RequestInterceptor;
import feign.Response;
import feign.codec.ErrorDecoder;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class FeignClientConfig {

    @Bean
    public RequestInterceptor feignAuthInterceptor() {
        return new FeignAuthInterceptor();
    }

    /**
     * Turn HTTP error bodies into a simple exception whose message is the API "detail"
     * (e.g. "Email already registered") so the UI can show it directly.
     */
    @Bean
    public ErrorDecoder feignErrorDecoder() {
        return (methodKey, response) -> {
            String message = readDetail(response);
            if (message == null || message.isBlank()) {
                message = "Request failed (HTTP " + response.status() + ")";
            }
            return new IllegalArgumentException(message);
        };
    }

    private static String readDetail(Response response) {
        if (response.body() == null) {
            return null;
        }
        try (InputStream in = response.body().asInputStream()) {
            String body = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            String detail = field(body, "detail");
            return detail != null ? detail : (body.isBlank() ? null : body);
        } catch (IOException e) {
            return null;
        }
    }

    private static String field(String json, String name) {
        int key = json.indexOf("\"" + name + "\"");
        if (key < 0) {
            return null;
        }
        int colon = json.indexOf(':', key);
        int start = json.indexOf('"', colon + 1);
        if (start < 0) {
            return null;
        }
        StringBuilder value = new StringBuilder();
        for (int i = start + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) {
                value.append(json.charAt(++i));
                continue;
            }
            if (c == '"') {
                return value.toString();
            }
            value.append(c);
        }
        return null;
    }
}
