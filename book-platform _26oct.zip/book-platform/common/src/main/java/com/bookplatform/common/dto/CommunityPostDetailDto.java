package com.bookplatform.common.dto;

import java.util.List;

public record CommunityPostDetailDto(
        CommunityPostDto post,
        List<CommunityReplyDto> replies
) {
}
