package com.bookplatform.common.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateCommunityReplyRequest(
        @NotBlank @Size(max = 2000) String body,
        @NotBlank @Size(max = 120) String userFullName
) {
}
