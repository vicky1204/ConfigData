package com.bookplatform.common.dto;

/**
 * Registration account type. Maps to {@link UserRole#USER} or {@link UserRole#STORE_ADMIN}.
 * Platform {@link UserRole#ADMIN} cannot be self-registered.
 */
public enum AccountType {
    USER,
    STORE
}
