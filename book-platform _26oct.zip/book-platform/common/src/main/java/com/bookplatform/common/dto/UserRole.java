package com.bookplatform.common.dto;

public enum UserRole {
    USER,
    STORE_ADMIN,
    ADMIN
}
