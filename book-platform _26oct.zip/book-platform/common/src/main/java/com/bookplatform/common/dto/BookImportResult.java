package com.bookplatform.common.dto;

import java.util.List;

public record BookImportResult(
        int imported,
        int failed,
        List<String> errors
) {
}
