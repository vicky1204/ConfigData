package com.bookplatform.common.client;

import com.bookplatform.common.config.FeignClientConfig;
import com.bookplatform.common.constants.ServiceNames;
import com.bookplatform.common.dto.CommunityPostDetailDto;
import com.bookplatform.common.dto.CommunityPostDto;
import com.bookplatform.common.dto.CommunityReplyDto;
import com.bookplatform.common.dto.CreateCommunityPostRequest;
import com.bookplatform.common.dto.CreateCommunityReplyRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(
        name = ServiceNames.USER_SERVICE + "-community",
        url = "${bookplatform.services.user-url}",
        configuration = FeignClientConfig.class
)
public interface CommunityServiceClient {

    @GetMapping("/api/community/posts")
    List<CommunityPostDto> listPosts();

    @GetMapping("/api/community/posts/{id}")
    CommunityPostDetailDto getPost(@PathVariable("id") Long id);

    @PostMapping("/api/community/posts")
    CommunityPostDto createPost(@RequestBody CreateCommunityPostRequest request);

    @PostMapping("/api/community/posts/{id}/replies")
    CommunityReplyDto createReply(@PathVariable("id") Long id, @RequestBody CreateCommunityReplyRequest request);
}
