package com.bookplatform.common.dto;

import java.time.Instant;

public record CommunityReplyDto(
        Long id,
        Long postId,
        Long userId,
        String userFullName,
        String body,
        Instant createdAt
) {
}
