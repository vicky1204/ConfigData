package com.bookplatform.common.config;

import com.bookplatform.common.security.AuthTokenHolder;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class FeignAuthInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate template) {
        if (template.headers().containsKey(HttpHeaders.AUTHORIZATION)) {
            return;
        }
        String token = AuthTokenHolder.get();
        if (token == null || token.isBlank()) {
            token = tokenFromCurrentRequest();
        }
        if (token != null && !token.isBlank()) {
            if (token.regionMatches(true, 0, "Bearer ", 0, 7)) {
                template.header(HttpHeaders.AUTHORIZATION, token);
            } else {
                template.header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
            }
        }
    }

    private static String tokenFromCurrentRequest() {
        RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
        if (!(attrs instanceof ServletRequestAttributes servletAttrs)) {
            return null;
        }
        String header = servletAttrs.getRequest().getHeader(HttpHeaders.AUTHORIZATION);
        if (header == null || header.isBlank()) {
            return null;
        }
        if (header.regionMatches(true, 0, "Bearer ", 0, 7)) {
            return header.substring(7).trim();
        }
        return header.trim();
    }
}
